# YESMIN AI – Android Studio Project

यह शुरुआती Android app project है। इसमें Gemini chat, Hindi speech-to-text, text-to-speech, Gemini API key settings और YouTube search shortcut शामिल हैं। यह अभी Maya/Jarvis जैसा पूर्ण phone-control assistant नहीं है।

## APK बनाने का तरीका
1. कंप्यूटर पर Android Studio का नवीनतम stable संस्करण इंस्टॉल करें।
2. Android Studio में **Open** चुनकर `YesminAI` फ़ोल्डर खोलें।
3. Gradle sync पूरा होने दें और Android SDK Platform 35 इंस्टॉल करें।
4. Run दबाकर फोन/एम्युलेटर पर जाँचें।
5. APK के लिए **Build > Build Bundle(s) / APK(s) > Build APK(s)** चुनें।
6. APK सामान्यतः `app/build/outputs/apk/debug/app-debug.apk` में मिलेगा।

## Gemini API key
Google AI Studio से अपनी Gemini API key बनाएँ और ऐप के Settings में डालें। API key निजी रखें। इस demo में key डिवाइस के SharedPreferences में सेव होती है; सार्वजनिक रिलीज़ के लिए सुरक्षित backend proxy बेहतर है।

## सीमाएँ
- YouTube सुविधा search page खोलती है; यह YouTube playback को background से नियंत्रित नहीं करती।
- सामान्य ऐप खोलना, कॉल/मैसेज, notification reading, screen reading और system settings के लिए अतिरिक्त Android intents, permissions और user confirmations लागू करने होंगे।
- इस प्रोजेक्ट को APK में compile/test नहीं किया गया है।

## GitHub से APK बनवाने का विकल्प
इस प्रोजेक्ट में `.github/workflows/build-apk.yml` जोड़ा गया है। फ़ोल्डर को GitHub repository में upload/push करने पर Actions workflow APK build करके `yesmin-ai-debug-apk` नाम का artifact देगा। GitHub में repository खोलें → Actions → Build YESMIN AI APK → workflow run पूरा होने पर artifact डाउनलोड करें।

package com.yesminai.assistant

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { YesminApp() }
    }
}

private data class ChatLine(val text: String, val fromUser: Boolean)

@Composable
private fun YesminApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("yesmin", 0) }
    var apiKey by remember { mutableStateOf(prefs.getString("gemini_key", "") ?: "") }
    var showSettings by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val lines = remember { mutableStateListOf(ChatLine("नमस्ते! मैं YESMIN AI हूँ। आज मैं आपकी क्या मदद करूँ?", false)) }
    val scope = rememberCoroutineScope()
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    DisposableEffect(context) {
        val engine = TextToSpeech(context) { status -> if (status == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN") }
        tts = engine
        onDispose { engine.stop(); engine.shutdown(); tts = null }
    }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) input = spoken
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFB68CFF), background = Color(0xFF080A16), surface = Color(0xFF15182B))) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF10152D), Color(0xFF070812))))) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.weight(1f)) {
                        Text("✦ YESMIN AI", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("Your smart AI companion", color = Color(0xFFB9A4E8), fontSize = 12.sp)
                    }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings", tint = Color.White) }
                }
                Spacer(Modifier.height(18.dp))
                Box(Modifier.fillMaxWidth().height(145.dp).background(Brush.linearGradient(listOf(Color(0xFF422078), Color(0xFF123C68))), RoundedCornerShape(24.dp)), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("✧", color = Color(0xFFE4C8FF), fontSize = 44.sp)
                        Text("Hello! I’m YESMIN", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Text("आपकी AI सहायक", color = Color(0xFFD8C9F5), fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(lines) { line ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                            Surface(color = if (line.fromUser) Color(0xFF55369A) else Color(0xFF1B2138), shape = RoundedCornerShape(18.dp), modifier = Modifier.widthIn(max = 310.dp)) {
                                Text(line.text, color = Color.White, modifier = Modifier.padding(13.dp), fontSize = 15.sp)
                            }
                        }
                    }
                    if (busy) item { Text("YESMIN सोच रही है…", color = Color(0xFFC8B2F4)) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), placeholder = { Text("अपना संदेश लिखें…") }, maxLines = 4, shape = RoundedCornerShape(18.dp), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Color(0xFFB68CFF), unfocusedBorderColor = Color(0xFF55516C)))
                    Spacer(Modifier.width(6.dp))
                    IconButton(onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "YESMIN से बात करें")
                        }
                        try { speechLauncher.launch(intent) } catch (_: Exception) { lines.add(ChatLine("इस फोन में Speech Recognition उपलब्ध नहीं है।", false)) }
                    }) { Icon(Icons.Default.Mic, "Speak", tint = Color(0xFFD6B8FF)) }
                    IconButton(enabled = input.isNotBlank() && !busy, onClick = {
                        val msg = input.trim(); input = ""; lines.add(ChatLine(msg, true))
                        val command = msg.lowercase(Locale.ROOT)
                        if (command.contains("youtube") || command.contains("यूट्यूब")) {
                            val query = msg.replace(Regex("(?i)youtube|यूट्यूब"), "").trim()
                            val url = "https://www.youtube.com/results?search_query=" + java.net.URLEncoder.encode(query.ifBlank { "music" }, "UTF-8")
                            context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)))
                            lines.add(ChatLine("YouTube search खोल दिया है।", false))
                        } else {
                            busy = true
                            scope.launch {
                                val reply = askGemini(apiKey, msg)
                                lines.add(ChatLine(reply, false))
                                tts?.speak(reply, TextToSpeech.QUEUE_FLUSH, null, "yesmin_reply")
                                busy = false
                            }
                        }
                    }) { Icon(Icons.Default.Send, "Send", tint = Color(0xFFD6B8FF)) }
                }
                Text("AI जवाबों को जाँच लें। फोन के संवेदनशील कामों के लिए आपकी अनुमति जरूरी है।", color = Color(0xFF9293A8), fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp))
            }
        }
        if (showSettings) AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("YESMIN AI Settings") },
            text = { Column {
                Text("Gemini API Key", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = apiKey, onValueChange = { apiKey = it }, placeholder = { Text("अपनी API key डालें") }, singleLine = true)
                Text("Key इस डिवाइस पर स्थानीय रूप से सेव होगी। इसे किसी के साथ साझा न करें।", fontSize = 11.sp)
            } },
            confirmButton = { TextButton(onClick = { prefs.edit().putString("gemini_key", apiKey.trim()).apply(); showSettings = false }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Cancel") } }
        )
    }
}

private suspend fun askGemini(key: String, prompt: String): String = withContext(Dispatchers.IO) {
    if (key.isBlank()) return@withContext "पहले Settings में अपनी Gemini API key जोड़ें।"
    try {
        val json = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "You are YESMIN AI, a friendly and helpful Hindi-English assistant. Be concise and safe. User: $prompt")))))
        val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$key").post(body).build()
        OkHttpClient().newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) return@withContext "Gemini API error (${response.code}). API key और इंटरनेट कनेक्शन जाँचें।"
            JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")?.optJSONObject(0)?.optString("text") ?: "माफ़ कीजिए, जवाब नहीं मिल पाया।"
        }
    } catch (e: Exception) { "कनेक्शन में समस्या है: ${e.localizedMessage ?: "कृपया फिर कोशिश करें।"}" }
}
